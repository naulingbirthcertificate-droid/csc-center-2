@echo off
cd /d %~dp0
py -m venv .venv
call .venv\Scripts\activate
py -m pip install -r backend\requirements.txt
if "%CSC_SECRET_KEY%"=="" set CSC_SECRET_KEY=please-change-this-secret-before-public-deployment
py -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
pause
