NAULING MOBILE CSC CENTER GANAI GANGOLI — NOTIFICATION PORTAL

Included:
- Three-column Sarkari-Result-inspired homepage
- CSC Services / Government Schemes / Online Forms
- Latest notifications and scrolling notice bar
- Search across directory links and updates
- Admin setup on first run, admin login, add/edit/delete directory links,
  publish/delete latest updates, publish/delete notices, optional WhatsApp channel setting
- SQLite database stored in data/portal.sqlite3
- No phone number and no CSC ID displayed anywhere

RUN ON WINDOWS:
1. Install Python 3.10 or newer.
2. Extract this ZIP.
3. Double-click run.bat.
4. Wait for dependencies to install.
5. Open http://127.0.0.1:8000 in your browser.
6. Click Admin Login and create your first admin username and password.
   Password must be at least 10 characters.

RUN ON MAC / LINUX:
1. Install Python 3.10 or newer.
2. Extract ZIP.
3. In terminal run: chmod +x run.sh && ./run.sh
4. Open http://127.0.0.1:8000
5. Click Admin Login and create the first admin account.

PUBLISHING ONLINE:
This is a Python FastAPI + SQLite application, not just static HTML.
Deploy the project on a Python-capable host (Render, Railway, VPS, etc.).
Use a persistent disk/volume for data/portal.sqlite3 so content survives redeploys.
Set CSC_SECRET_KEY to a long random secret in the hosting environment.
Use HTTPS. Do not use the local development server as a public production setup.
SQLite is suitable for a small single-instance site; use PostgreSQL for larger/multi-instance hosting.

CONTACT:
Email: naulingmobilecsc@gmail.com
Location: Ganai Gangoli, Pithoragarh, Uttarakhand, India.

NOTES:
- No phone number or CSC ID is included.
- Directory entries without an official URL link to email enquiry; set verified official URLs
  in the Admin panel when available.
- This portal does not submit applications to government portals and does not claim
  government affiliation. Verify eligibility, deadlines, documents and fees with official sources.
