#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
source .venv/bin/activate
pip install -r backend/requirements.txt
export CSC_SECRET_KEY="${CSC_SECRET_KEY:-$(python3 -c 'import secrets; print(secrets.token_urlsafe(48))')}"
python -m uvicorn backend.main:app --host 0.0.0.0 --port "${PORT:-8000}"
