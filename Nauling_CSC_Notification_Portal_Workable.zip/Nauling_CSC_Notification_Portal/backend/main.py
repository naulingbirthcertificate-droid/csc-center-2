from __future__ import annotations
import os, sqlite3, hashlib, hmac, secrets, json
from datetime import datetime, timezone, date
from pathlib import Path
from typing import Optional
from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent.parent
DB_PATH = Path(os.getenv("CSC_DB_PATH", str(ROOT / "data" / "portal.sqlite3")))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
SECRET = os.getenv("CSC_SECRET_KEY", "CHANGE_THIS_SECRET_KEY_BEFORE_PUBLIC_DEPLOYMENT")
FRONTEND = ROOT / "frontend"

app = FastAPI(title="Nauling Mobile CSC Center Notification Portal", version="1.0.0")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS admins(
          id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
          password_hash TEXT NOT NULL, salt TEXT NOT NULL, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS link_items(
          id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL,
          name TEXT NOT NULL, hindi TEXT DEFAULT '', url TEXT DEFAULT '',
          is_new INTEGER DEFAULT 0, sort_order INTEGER DEFAULT 0,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS updates(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          url TEXT DEFAULT '', date TEXT NOT NULL, is_active INTEGER DEFAULT 1,
          created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS notices(
          id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL,
          body TEXT DEFAULT '', is_active INTEGER DEFAULT 1, created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        count = con.execute("SELECT COUNT(*) FROM link_items").fetchone()[0]
        if count == 0:
            seed = {
              "services": ["PAN Card आवेदन / संशोधन","आयुष्मान कार्ड / ABHA","ई-श्रम कार्ड","वोटर ID आवेदन / संशोधन","पासपोर्ट आवेदन","ड्राइविंग लाइसेंस सेवा","परिवार रजिस्टर की नकल","प्रिंट, स्कैन और फोटोकॉपी","ऑनलाइन फॉर्म भरना","बिल भुगतान सेवा","डिजिटल दस्तावेज़ सहायता"],
              "schemes": ["PM किसान सम्मान निधि","आयुष्मान भारत योजना","ई-श्रम योजना","वृद्धावस्था पेंशन","विधवा पेंशन","दिव्यांग पेंशन","छात्रवृत्ति योजनाएँ","प्रधानमंत्री आवास योजना","जनधन योजना","अन्य सरकारी योजना जानकारी"],
              "forms": ["जाति प्रमाण पत्र आवेदन","आय प्रमाण पत्र आवेदन","स्थायी निवास प्रमाण पत्र आवेदन","चरित्र प्रमाण पत्र आवेदन","छात्रवृत्ति ऑनलाइन फॉर्म","पेंशन ऑनलाइन आवेदन","रोजगार पंजीकरण","स्कूल / कॉलेज प्रवेश फॉर्म","सरकारी भर्ती ऑनलाइन फॉर्म","प्रतियोगी परीक्षा आवेदन","अन्य ऑनलाइन आवेदन"]
            }
            now = datetime.now(timezone.utc).isoformat()
            for cat, names in seed.items():
                for i, name in enumerate(names):
                    con.execute("INSERT INTO link_items(category,name,hindi,url,is_new,sort_order,created_at) VALUES(?,?,?,?,?,?,?)",
                                (cat, name, name, "", 0, i, now))
        if con.execute("SELECT COUNT(*) FROM notices").fetchone()[0] == 0:
            con.execute("INSERT INTO notices(title,body,is_active,created_at) VALUES(?,?,1,?)",
                        ("महत्वपूर्ण सूचना", "सेवा की पात्रता, आवश्यक दस्तावेज़ और शुल्क आवेदन से पहले संबंधित आधिकारिक पोर्टल/केन्द्र से सत्यापित करें।", datetime.now(timezone.utc).isoformat()))

init_db()

def hash_password(password: str, salt: Optional[str] = None):
    salt = salt or secrets.token_hex(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode(), bytes.fromhex(salt), 240000).hex()
    return digest, salt

def make_token(username: str):
    import base64, time
    payload = f"{username}|{int(time.time()) + 60*60*12}"
    sig = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    return base64.urlsafe_b64encode(f"{payload}|{sig}".encode()).decode()

def verify_token(token: str):
    import base64, time
    try:
        raw = base64.urlsafe_b64decode(token.encode()).decode()
        username, exp, sig = raw.rsplit("|", 2)
        payload = f"{username}|{exp}"
        expected = hmac.new(SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected) or int(exp) < int(time.time()):
            return None
        return username
    except Exception:
        return None

def admin_user(authorization: Optional[str] = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(401, "Admin login required")
    username = verify_token(authorization[7:])
    if not username:
        raise HTTPException(401, "Session expired. Please log in again.")
    return username

class SetupIn(BaseModel):
    username: str = Field(min_length=3, max_length=40)
    password: str = Field(min_length=10, max_length=128)
class LoginIn(BaseModel):
    username: str
    password: str
class LinkIn(BaseModel):
    category: str
    name: str
    hindi: str = ""
    url: str = ""
    is_new: bool = False
    sort_order: int = 0
class UpdateIn(BaseModel):
    title: str
    url: str = ""
    date: str = ""
    is_active: bool = True
class NoticeIn(BaseModel):
    title: str
    body: str = ""
    is_active: bool = True
class SettingsIn(BaseModel):
    whatsapp_group_url: str = ""

@app.get("/api/health")
def health():
    return {"ok": True, "app": "Nauling CSC Portal"}

@app.get("/api/setup-status")
def setup_status():
    with db() as con:
        n = con.execute("SELECT COUNT(*) FROM admins").fetchone()[0]
    return {"setup_required": n == 0}

@app.post("/api/setup")
def setup(data: SetupIn):
    with db() as con:
        if con.execute("SELECT COUNT(*) FROM admins").fetchone()[0]:
            raise HTTPException(409, "Admin is already configured.")
        digest, salt = hash_password(data.password)
        con.execute("INSERT INTO admins(username,password_hash,salt,created_at) VALUES(?,?,?,?)",
                    (data.username, digest, salt, datetime.now(timezone.utc).isoformat()))
    return {"ok": True, "token": make_token(data.username), "username": data.username}

@app.post("/api/login")
def login(data: LoginIn):
    with db() as con:
        row = con.execute("SELECT * FROM admins WHERE username=?", (data.username,)).fetchone()
    if not row:
        raise HTTPException(401, "गलत यूज़रनेम या पासवर्ड")
    digest, _ = hash_password(data.password, row["salt"])
    if not hmac.compare_digest(digest, row["password_hash"]):
        raise HTTPException(401, "गलत यूज़रनेम या पासवर्ड")
    return {"ok": True, "token": make_token(data.username), "username": data.username}

@app.get("/api/public")
def public_data():
    with db() as con:
        links = con.execute("SELECT * FROM link_items ORDER BY category, sort_order, id").fetchall()
        updates = con.execute("SELECT * FROM updates WHERE is_active=1 ORDER BY date DESC,id DESC").fetchall()
        notices = con.execute("SELECT * FROM notices WHERE is_active=1 ORDER BY id DESC").fetchall()
        settings = {r["key"]: r["value"] for r in con.execute("SELECT * FROM settings").fetchall()}
    grouped = {"services": [], "schemes": [], "forms": []}
    for r in links:
        item = dict(r); item["is_new"] = bool(item["is_new"])
        grouped.setdefault(item["category"], []).append(item)
    return {"links": grouped,
            "updates": [dict(r) for r in updates],
            "notices": [dict(r) for r in notices],
            "settings": settings}

@app.get("/api/search")
def search(q: str = ""):
    q = q.strip()
    if not q:
        return {"results": []}
    with db() as con:
        rows = con.execute("""SELECT * FROM link_items WHERE name LIKE ? OR hindi LIKE ?
                              UNION ALL SELECT id,'updates' as category,title as name,title as hindi,url,0 as is_new,0 as sort_order,created_at
                              FROM updates WHERE is_active=1 AND title LIKE ?
                              ORDER BY category,sort_order""", (f"%{q}%", f"%{q}%", f"%{q}%")).fetchall()
    return {"results": [dict(r) for r in rows]}

@app.get("/api/admin/data")
def admin_data(_: str = Depends(admin_user)):
    with db() as con:
        links = [dict(r) for r in con.execute("SELECT * FROM link_items ORDER BY category,sort_order,id")]
        updates = [dict(r) for r in con.execute("SELECT * FROM updates ORDER BY date DESC,id DESC")]
        notices = [dict(r) for r in con.execute("SELECT * FROM notices ORDER BY id DESC")]
        settings = {r["key"]: r["value"] for r in con.execute("SELECT * FROM settings")}
    return {"links": links, "updates": updates, "notices": notices, "settings": settings}

@app.post("/api/admin/links")
def create_link(data: LinkIn, _: str = Depends(admin_user)):
    if data.category not in ("services","schemes","forms"):
        raise HTTPException(400, "Invalid category")
    with db() as con:
        cur = con.execute("""INSERT INTO link_items(category,name,hindi,url,is_new,sort_order,created_at)
                             VALUES(?,?,?,?,?,?,?)""",
                          (data.category,data.name,data.hindi,data.url,int(data.is_new),data.sort_order,datetime.now(timezone.utc).isoformat()))
        return {"id": cur.lastrowid}

@app.put("/api/admin/links/{item_id}")
def update_link(item_id: int, data: LinkIn, _: str = Depends(admin_user)):
    if data.category not in ("services","schemes","forms"):
        raise HTTPException(400, "Invalid category")
    with db() as con:
        cur = con.execute("""UPDATE link_items SET category=?,name=?,hindi=?,url=?,is_new=?,sort_order=?
                             WHERE id=?""",
                          (data.category,data.name,data.hindi,data.url,int(data.is_new),data.sort_order,item_id))
        if cur.rowcount == 0: raise HTTPException(404, "Not found")
    return {"ok": True}

@app.delete("/api/admin/links/{item_id}")
def delete_link(item_id: int, _: str = Depends(admin_user)):
    with db() as con:
        con.execute("DELETE FROM link_items WHERE id=?", (item_id,))
    return {"ok": True}

@app.post("/api/admin/updates")
def create_update(data: UpdateIn, _: str = Depends(admin_user)):
    d = data.date or date.today().isoformat()
    with db() as con:
        cur = con.execute("INSERT INTO updates(title,url,date,is_active,created_at) VALUES(?,?,?,?,?)",
                          (data.title,data.url,d,int(data.is_active),datetime.now(timezone.utc).isoformat()))
        return {"id": cur.lastrowid}

@app.put("/api/admin/updates/{item_id}")
def edit_update(item_id: int, data: UpdateIn, _: str = Depends(admin_user)):
    with db() as con:
        cur = con.execute("UPDATE updates SET title=?,url=?,date=?,is_active=? WHERE id=?",
                          (data.title,data.url,data.date or date.today().isoformat(),int(data.is_active),item_id))
        if not cur.rowcount: raise HTTPException(404,"Not found")
    return {"ok": True}

@app.delete("/api/admin/updates/{item_id}")
def delete_update(item_id: int, _: str = Depends(admin_user)):
    with db() as con: con.execute("DELETE FROM updates WHERE id=?", (item_id,))
    return {"ok": True}

@app.post("/api/admin/notices")
def create_notice(data: NoticeIn, _: str = Depends(admin_user)):
    with db() as con:
        cur = con.execute("INSERT INTO notices(title,body,is_active,created_at) VALUES(?,?,?,?)",
                          (data.title,data.body,int(data.is_active),datetime.now(timezone.utc).isoformat()))
        return {"id": cur.lastrowid}

@app.delete("/api/admin/notices/{item_id}")
def delete_notice(item_id: int, _: str = Depends(admin_user)):
    with db() as con: con.execute("DELETE FROM notices WHERE id=?", (item_id,))
    return {"ok": True}

@app.put("/api/admin/settings")
def save_settings(data: SettingsIn, _: str = Depends(admin_user)):
    with db() as con:
        con.execute("INSERT INTO settings(key,value) VALUES('whatsapp_group_url',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (data.whatsapp_group_url,))
    return {"ok": True}

@app.get("/")
def home():
    return FileResponse(FRONTEND / "index.html")

app.mount("/static", StaticFiles(directory=FRONTEND), name="static")
